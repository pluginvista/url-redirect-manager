<?php
/**
 * Plugin Name: URL Redirect Manager
 * Description: Manage URL redirects with history tracking and bulk operations
 * Version: 1.1
 * License: GPL v2 or later
 * Text Domain: url-redirect-manager
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class URL_Redirect_Manager {
    
    private $option_name = 'url_redirect_rules';
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('wp_ajax_um_delete_redirect', array($this, 'ajax_delete_redirect'));
        add_action('wp_ajax_um_clear_history', array($this, 'ajax_clear_history'));
    }
    
    public function init() {
        add_action('template_redirect', array($this, 'handle_redirects'));
    }
    
    public function handle_redirects() {
        if (is_admin()) {
            return; // Prevent redirects inside wp-admin
        }

        $redirects = get_option($this->option_name, array());
        $current_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH); // Only the path, no query string
        $current_path = untrailingslashit($current_path);

        foreach ($redirects as $rule) {
            $from = untrailingslashit($rule['from']);
            $to   = untrailingslashit($rule['to']);

            if ($current_path === $from) {
                // Add to history
                $this->add_to_history($from, $to);

                // Perform redirect
                wp_redirect(home_url($to), 301);
                exit;
            }
        }
    }
    
    public function add_to_history($from, $to) {
        $history = get_option('url_redirect_history', array());
        $history[] = array(
            'from' => $from,
            'to' => $to,
            'timestamp' => current_time('mysql'),
            'ip' => $_SERVER['REMOTE_ADDR']
        );
        
        // Keep only last 500 entries
        if (count($history) > 500) {
            array_splice($history, 0, count($history) - 500);
        }
        
        update_option('url_redirect_history', $history);
    }
    
    public function add_admin_menu() {
        add_options_page(
            'URL Redirect Manager',
            'Redirect Manager',
            'manage_options',
            'url-redirect-manager',
            array($this, 'admin_page')
        );
    }
    
    public function admin_page() {
        // Handle form submission
        if (isset($_POST['add_redirect'])) {
            $redirects = get_option($this->option_name, array());
            $new_rule = array(
                'from' => $this->normalize_url($_POST['from_url']),
                'to' => $this->normalize_url($_POST['to_url']),
                'date' => current_time('mysql')
            );
            
            // Prevent duplicates
            $exists = false;
            foreach ($redirects as $rule) {
                if ($rule['from'] === $new_rule['from']) {
                    $exists = true;
                    break;
                }
            }
            
            if (!$exists && !empty($new_rule['from']) && !empty($new_rule['to'])) {
                $redirects[] = $new_rule;
                update_option($this->option_name, $redirects);
            }
        }
        
        // Handle bulk delete
        if (isset($_POST['bulk_action']) && $_POST['bulk_action'] === 'delete') {
            $redirects = get_option($this->option_name, array());
            $selected = isset($_POST['selected']) ? $_POST['selected'] : array();
            
            foreach ($selected as $index) {
                unset($redirects[$index]);
            }
            
            update_option($this->option_name, array_values($redirects));
        }
        
        $redirects = get_option($this->option_name, array());
        $history = get_option('url_redirect_history', array());
        ?>
        <div class="wrap">
            <h1>URL Redirect Manager</h1>
            
            <h2>Add New Redirect</h2>
            <form method="post" action="">
                <table class="form-table">
                    <tr>
                        <th scope="row">From URL</th>
                        <td><input type="text" name="from_url" class="regular-text code" placeholder="/old-url" required /></td>
                    </tr>
                    <tr>
                        <th scope="row">To URL</th>
                        <td><input type="text" name="to_url" class="regular-text code" placeholder="/new-url" required /></td>
                    </tr>
                </table>
                <?php submit_button('Add Redirect', 'primary', 'add_redirect'); ?>
            </form>
            
            <h2>Current Redirects</h2>
            <form method="post" action="">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <td id="cb" class="manage-column column-cb check-column">
                                <input id="cb-select-all-1" type="checkbox">
                            </td>
                            <th>From URL</th>
                            <th>To URL</th>
                            <th>Date Added</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($redirects as $index => $rule): ?>
                        <tr>
                            <th scope="row" class="check-column">
                                <input type="checkbox" name="selected[]" value="<?php echo $index; ?>" />
                            </th>
                            <td><code><?php echo esc_html($rule['from']); ?></code></td>
                            <td><code><?php echo esc_html($rule['to']); ?></code></td>
                            <td><?php echo esc_html($rule['date']); ?></td>
                            <td>
                                <button type="button" class="button delete-redirect" data-id="<?php echo $index; ?>">Delete</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="tablenav top">
                    <div class="alignleft actions bulkactions">
                        <select name="bulk_action" id="bulk-action-selector-top">
                            <option value="-1">Bulk Actions</option>
                            <option value="delete">Delete</option>
                        </select>
                        <input type="submit" class="button action" value="Apply">
                    </div>
                </div>
            </form>
            
            <h2>Redirect History</h2>
            <div style="margin-bottom: 10px;">
                <button type="button" class="button button-secondary" id="clear-history">Clear History</button>
            </div>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>From URL</th>
                        <th>To URL</th>
                        <th>Time</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (array_reverse($history) as $entry): ?>
                    <tr>
                        <td><code><?php echo esc_html($entry['from']); ?></code></td>
                        <td><code><?php echo esc_html($entry['to']); ?></code></td>
                        <td><?php echo esc_html($entry['timestamp']); ?></td>
                        <td><?php echo esc_html($entry['ip']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('.delete-redirect').click(function() {
                var ruleIndex = $(this).data('id');
                if (confirm('Are you sure you want to delete this redirect?')) {
                    $.post(ajaxurl, {
                        action: 'um_delete_redirect',
                        rule_index: ruleIndex,
                        nonce: '<?php echo wp_create_nonce("um_redirect_nonce"); ?>'
                    }, function() {
                        location.reload();
                    });
                }
            });
            
            $('#clear-history').click(function() {
                if (confirm('Are you sure you want to clear all redirect history?')) {
                    $.post(ajaxurl, {
                        action: 'um_clear_history',
                        nonce: '<?php echo wp_create_nonce("um_history_nonce"); ?>'
                    }, function() {
                        location.reload();
                    });
                }
            });
        });
        </script>
        <?php
    }
    
    private function normalize_url($url) {
        $url = trim($url);
        $parts = parse_url($url);

        if (isset($parts['path'])) {
            $url = '/' . ltrim($parts['path'], '/');
        } else {
            $url = '/' . ltrim($url, '/');
        }

        return untrailingslashit($url);
    }
    
    public function ajax_delete_redirect() {
        check_ajax_referer('um_redirect_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die();
        }
        
        $redirects = get_option($this->option_name, array());
        $index = intval($_POST['rule_index']);
        
        if (isset($redirects[$index])) {
            unset($redirects[$index]);
            update_option($this->option_name, array_values($redirects));
        }
        
        wp_die();
    }
    
    public function ajax_clear_history() {
        check_ajax_referer('um_history_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die();
        }
        
        update_option('url_redirect_history', array());
        wp_die();
    }
}

new URL_Redirect_Manager();
